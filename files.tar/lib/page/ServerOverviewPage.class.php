<?php
// wcf imports
require_once(WCF_DIR.'lib/page/AbstractPage.class.php');

/**
 * Just an example page
 *
 * @author    zerocool
 * @copyright    2013 sexygaming.de
 * @package    de.sexygaming.tsviewer
 * @license    insert it here
 */
class ServerOverviewPage extends AbstractPage {
    // ServerOverview.tpl
    public $templateName = 'ServerOverview';
    
}
?>
